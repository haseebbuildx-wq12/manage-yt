<?php
final class YouTube {
    public function __construct(private string $accessToken, private int $chunkSize = 8388608) {}

    private function api(string $method, string $url, ?string $json = null): array {
        $ch = curl_init($url);
        $headers = ['Authorization: Bearer ' . $this->accessToken, 'Accept: application/json'];
        if ($json !== null) $headers[] = 'Content-Type: application/json';
        curl_setopt_array($ch, [
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_TIMEOUT => 120,
        ]);
        if ($json !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
        $raw = curl_exec($ch);
        if ($raw === false) throw new RuntimeException('YouTube API: '.curl_error($ch));
        $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        $data = json_decode($raw, true);
        if ($status >= 400) throw new RuntimeException('YouTube API HTTP '.$status.': '.($data['error']['message'] ?? $raw));
        return is_array($data) ? $data : [];
    }

    public function channel(): array {
        return $this->api('GET', 'https://www.googleapis.com/youtube/v3/channels?part=snippet,contentDetails&mine=true');
    }

    public function uploadResumable(string $filePath, array $meta): array {
        $size = filesize($filePath);
        if ($size === false || $size <= 0) throw new RuntimeException('Temporary video file is empty.');
        $url = 'https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status';
        $payload = [
            'snippet' => [
                'title' => $meta['title'],
                'description' => $meta['description'],
                'tags' => $meta['tags'],
                'categoryId' => (string)$meta['category_id'],
            ],
            'status' => [
                'privacyStatus' => $meta['privacy_status'],
                'selfDeclaredMadeForKids' => (bool)$meta['made_for_kids'],
            ],
        ];
        if ($meta['privacy_status'] === 'private' && !empty($meta['publish_at'])) {
            $payload['status']['publishAt'] = gmdate('Y-m-d\TH:i:s\Z', strtotime($meta['publish_at']));
        }

        $location = null;
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer '.$this->accessToken,
                'Content-Type: application/json; charset=UTF-8',
                'X-Upload-Content-Length: '.$size,
                'X-Upload-Content-Type: '.($meta['mime_type'] ?: 'application/octet-stream'),
            ],
            CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
            CURLOPT_TIMEOUT => 120,
            CURLOPT_HEADERFUNCTION => function($ch, $header) use (&$location) {
                if (stripos($header, 'Location:') === 0) $location = trim(substr($header, 9));
                return strlen($header);
            },
        ]);
        $raw = curl_exec($ch);
        if ($raw === false) throw new RuntimeException('YouTube upload initiation: '.curl_error($ch));
        $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if (!$location || $status < 200 || $status >= 300) {
            throw new RuntimeException('YouTube upload initiation failed HTTP '.$status.': '.($raw ?: 'no resumable URL'));
        }
        return $this->uploadChunks($location, $filePath, $size, $meta['mime_type'] ?: 'application/octet-stream');
    }

    private function uploadChunks(string $location, string $filePath, int $size, string $mime): array {
        $fp = fopen($filePath, 'rb');
        if (!$fp) throw new RuntimeException('Cannot open upload file.');
        $offset = 0;
        try {
            while ($offset < $size) {
                $length = min($this->chunkSize, $size - $offset);
                fseek($fp, $offset);
                $data = fread($fp, $length);
                if ($data === false || strlen($data) !== $length) throw new RuntimeException('Cannot read upload chunk.');
                $end = $offset + $length - 1;
                $responseHeaders = [];
                $ch = curl_init($location);
                curl_setopt_array($ch, [
                    CURLOPT_CUSTOMREQUEST => 'PUT',
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_HTTPHEADER => [
                        'Authorization: Bearer '.$this->accessToken,
                        'Content-Length: '.$length,
                        'Content-Type: '.$mime,
                        'Content-Range: bytes '.$offset.'-'.$end.'/'.$size,
                    ],
                    CURLOPT_POSTFIELDS => $data,
                    CURLOPT_TIMEOUT => 0,
                    CURLOPT_HEADERFUNCTION => function($ch, $header) use (&$responseHeaders) {
                        $len = strlen($header);
                        $header = trim($header);
                        if ($header !== '' && str_contains($header, ':')) {
                            [$k,$v] = explode(':',$header,2);
                            $responseHeaders[strtolower(trim($k))] = trim($v);
                        }
                        return $len;
                    },
                ]);
                $raw = curl_exec($ch);
                if ($raw === false) throw new RuntimeException('YouTube chunk upload: '.curl_error($ch));
                $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);

                if ($status === 308) {
                    if (isset($responseHeaders['range']) && preg_match('/bytes=0-(\d+)/', $responseHeaders['range'], $m)) {
                        $offset = ((int)$m[1]) + 1;
                    } else $offset += $length;
                    continue;
                }
                $json = json_decode($raw, true);
                if ($status >= 200 && $status < 300 && is_array($json)) return $json;
                throw new RuntimeException('YouTube upload HTTP '.$status.': '.($json['error']['message'] ?? $raw));
            }
        } finally { fclose($fp); }
        throw new RuntimeException('Upload ended without a YouTube response.');
    }
}
