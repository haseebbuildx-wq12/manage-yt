<?php
declare(strict_types=1);
$configFile=__DIR__.'/../config/config.php';
if(!is_file($configFile)){
    if(PHP_SAPI!=='cli'){ header('Location: install.php'); exit; }
    throw new RuntimeException('Application is not installed.');
}
$config=require $configFile;
date_default_timezone_set('UTC');
require_once __DIR__.'/helpers.php';require_once __DIR__.'/Database.php';require_once __DIR__.'/Security.php';require_once __DIR__.'/GoogleOAuth.php';require_once __DIR__.'/GoogleDrive.php';require_once __DIR__.'/YouTube.php';require_once __DIR__.'/Scheduler.php';require_once __DIR__.'/Services.php';
$db=new Database($config['db']);
if(!$db->one("SHOW TABLES LIKE 'admins'")) { if(PHP_SAPI!=='cli'){ header('Location: install.php'); exit; } throw new RuntimeException('Database is not installed.'); }
$security=new Security($config['app']['app_key'],$config['app']['session_name']);if(PHP_SAPI!=='cli')$security->startSession();$oauth=new GoogleOAuth($config,$db,$security);$services=new Services($db,$security,$oauth,$config);
