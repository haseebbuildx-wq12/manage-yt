<?php
final class Security {
    public function __construct(private string $appKey, private string $sessionName) {
        if (!preg_match('/^[a-f0-9]{64}$/', $appKey)) {
            throw new RuntimeException('APP_KEY must be 64 hexadecimal characters.');
        }
    }

    public function startSession(): void {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_name($this->sessionName);
            session_set_cookie_params([
                'httponly' => true,
                'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
                'samesite' => 'Lax',
                'path' => '/',
            ]);
            session_start();
        }
    }

    public function csrf(): string {
        $this->startSession();
        if (empty($_SESSION['_csrf'])) $_SESSION['_csrf'] = bin2hex(random_bytes(24));
        return $_SESSION['_csrf'];
    }

    public function verifyCsrf(?string $token): void {
        $this->startSession();
        if (!$token || empty($_SESSION['_csrf']) || !hash_equals($_SESSION['_csrf'], $token)) {
            http_response_code(419);
            exit('Invalid CSRF token.');
        }
    }

    public function login(int $adminId): void {
        $this->startSession();
        session_regenerate_id(true);
        $_SESSION['admin_id'] = $adminId;
    }

    public function logout(): void {
        $this->startSession();
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $p['path'], '', $p['secure'], $p['httponly']);
        }
        session_destroy();
    }

    public function adminId(): ?int {
        $this->startSession();
        return isset($_SESSION['admin_id']) ? (int)$_SESSION['admin_id'] : null;
    }

    public function requireAdmin(): void {
        if (!$this->adminId()) redirect(base_url('login.php'));
    }

    public function encrypt(string $plaintext): string {
        $key = hex2bin($this->appKey);
        $iv = random_bytes(12);
        $tag = '';
        $cipher = openssl_encrypt($plaintext, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);
        if ($cipher === false) throw new RuntimeException('Encryption failed.');
        return base64_encode($iv . $tag . $cipher);
    }

    public function decrypt(string $encoded): string {
        $raw = base64_decode($encoded, true);
        if ($raw === false || strlen($raw) < 28) throw new RuntimeException('Invalid encrypted data.');
        $iv = substr($raw, 0, 12);
        $tag = substr($raw, 12, 16);
        $cipher = substr($raw, 28);
        $plain = openssl_decrypt($cipher, 'aes-256-gcm', hex2bin($this->appKey), OPENSSL_RAW_DATA, $iv, $tag);
        if ($plain === false) throw new RuntimeException('Decryption failed.');
        return $plain;
    }
}
