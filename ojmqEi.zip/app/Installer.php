<?php
declare(strict_types=1);

final class Installer {
    public static function schemaPath(): string { return __DIR__.'/../database/schema.sql'; }
    public static function install(array $dbCfg, string $appBaseUrl, string $googleClientId, string $googleClientSecret, string $adminEmail, string $adminPassword): void {
        if (!filter_var($adminEmail, FILTER_VALIDATE_EMAIL)) throw new RuntimeException('Enter a valid admin email.');
        if (strlen($adminPassword) < 10) throw new RuntimeException('Admin password must be at least 10 characters.');
        $pdo = new PDO(sprintf('mysql:host=%s;port=%d;charset=%s', $dbCfg['host'], $dbCfg['port'], $dbCfg['charset']), $dbCfg['user'], $dbCfg['pass'], [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
        $dbName = str_replace('`','``',$dbCfg['name']);
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$dbName}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $pdo->exec("USE `{$dbName}`");
        $schema = file_get_contents(self::schemaPath());
        if ($schema === false) throw new RuntimeException('Database schema file is missing.');
        foreach (self::splitSql($schema) as $statement) { if (trim($statement)!=='') $pdo->exec($statement); }
        $now = gmdate('Y-m-d H:i:s');
        $stmt=$pdo->prepare('SELECT COUNT(*) FROM admins'); $stmt->execute();
        if ((int)$stmt->fetchColumn() > 0) throw new RuntimeException('Installation is already completed.');
        $stmt=$pdo->prepare('INSERT INTO admins(email,password_hash,created_at,updated_at) VALUES(?,?,?,?)');
        $stmt->execute([$adminEmail,password_hash($adminPassword,PASSWORD_DEFAULT),$now,$now]);
        $stmt=$pdo->prepare('INSERT INTO settings(setting_key,setting_value,updated_at) VALUES(?,?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value),updated_at=VALUES(updated_at)');
        $stmt->execute(['installation_completed','1',$now]);
        $stmt->execute(['app_base_url',rtrim($appBaseUrl,'/'),$now]);
        $cfg = "<?php\nreturn ".var_export([
            'app'=>['name'=>'YT Multi-Channel Automation','base_url'=>rtrim($appBaseUrl,'/'),'timezone'=>'Asia/Karachi','app_key'=>bin2hex(random_bytes(32)),'cron_secret'=>bin2hex(random_bytes(32)),'session_name'=>'ytbot_admin'],
            'db'=>['host'=>$dbCfg['host'],'port'=>$dbCfg['port'],'name'=>$dbCfg['name'],'user'=>$dbCfg['user'],'pass'=>$dbCfg['pass'],'charset'=>'utf8mb4'],
            'google'=>['client_id'=>$googleClientId,'client_secret'=>$googleClientSecret,'redirect_base'=>rtrim($appBaseUrl,'/').'/oauth/google.php','scopes'=>['drive'=>'https://www.googleapis.com/auth/drive.readonly','youtube'=>'https://www.googleapis.com/auth/youtube.upload https://www.googleapis.com/auth/youtube.readonly']],
            'upload'=>['chunk_size'=>8*1024*1024,'max_retries'=>4,'private_upload_lead_minutes'=>10,'max_temp_file_bytes'=>0,'temp_dir'=>__DIR__.'/../storage/tmp'],
        ], true).";\n";
        if (file_put_contents(__DIR__.'/../config/config.php',$cfg,LOCK_EX)===false) throw new RuntimeException('Could not write config/config.php. Check permissions.');
        @chmod(__DIR__.'/../config/config.php',0600);
        file_put_contents(__DIR__.'/../storage/installed.lock','Installed: '.$now."\n",LOCK_EX);
    }
    private static function splitSql(string $sql): array {
        $out=[];$buf='';$len=strlen($sql);$quote=null;$lineComment=false;$blockComment=false;
        for($i=0;$i<$len;$i++){
            $c=$sql[$i];$n=$i+1<$len?$sql[$i+1]:'';
            if($lineComment){$buf.=$c;if($c==="\n")$lineComment=false;continue;}
            if($blockComment){if($c==='*'&&$n==='/'){$buf.='*/';$i++;$blockComment=false;}else$buf.=$c;continue;}
            if($quote!==null){$buf.=$c;if($c==='\\'&&$i+1<$len){$buf.=$sql[++$i];continue;}if($c===$quote){if($i+1<$len&&$sql[$i+1]===$quote){$buf.=$sql[++$i];}else$quote=null;}continue;}
            if($c==="'"||$c==='"'||$c==='`'){$quote=$c;$buf.=$c;continue;}
            if($c==='-'&&$n==='-'){$lineComment=true;$buf.='--';$i++;continue;}
            if($c==='#'){$lineComment=true;$buf.=$c;continue;}
            if($c==='/'&&$n==='*'){$blockComment=true;$buf.='/*';$i++;continue;}
            if($c===';'){ $out[]=trim($buf);$buf='';continue; }
            $buf.=$c;
        }
        if(trim($buf)!=='')$out[]=trim($buf); return $out;
    }
}
