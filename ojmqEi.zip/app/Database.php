<?php
final class Database {
    private PDO $pdo;

    public function __construct(array $cfg) {
        $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=%s',
            $cfg['host'], $cfg['port'], $cfg['name'], $cfg['charset']);
        $this->pdo = new PDO($dsn, $cfg['user'], $cfg['pass'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    }

    public function pdo(): PDO { return $this->pdo; }

    public function one(string $sql, array $params = []): ?array {
        $s = $this->pdo->prepare($sql);
        $s->execute($params);
        $r = $s->fetch();
        return $r ?: null;
    }

    public function all(string $sql, array $params = []): array {
        $s = $this->pdo->prepare($sql);
        $s->execute($params);
        return $s->fetchAll();
    }

    public function exec(string $sql, array $params = []): int {
        $s = $this->pdo->prepare($sql);
        $s->execute($params);
        return $s->rowCount();
    }

    public function insert(string $sql, array $params = []): int {
        $s = $this->pdo->prepare($sql);
        $s->execute($params);
        return (int)$this->pdo->lastInsertId();
    }

    public function transaction(callable $fn): mixed {
        $this->pdo->beginTransaction();
        try {
            $result = $fn();
            $this->pdo->commit();
            return $result;
        } catch (Throwable $e) {
            $this->pdo->rollBack();
            throw $e;
        }
    }
}
