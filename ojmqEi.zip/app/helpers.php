<?php
function now_sql(): string { return gmdate('Y-m-d H:i:s'); }
function e(?string $v): string { return htmlspecialchars($v ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function json_encode_safe($value): string { return json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR); }
function redirect(string $url): never { header('Location: '.$url); exit; }
function base_url(string $path=''): string { global $config; return rtrim($config['app']['base_url'],'/').'/'.ltrim($path,'/'); }
function request_method(): string { return strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET'); }
function post(string $key,mixed $default=null): mixed { return $_POST[$key] ?? $default; }
function get(string $key,mixed $default=null): mixed { return $_GET[$key] ?? $default; }
function is_post(): bool { return request_method()==='POST'; }
function parse_tags(string $input): array { $parts=preg_split('/[,\n]+/',$input) ?: []; $out=[]; foreach($parts as $p){$p=trim($p);if($p!=='')$out[]=ltrim($p,'#');} return array_values(array_unique($out)); }
function clean_title_from_filename(string $name): string { $name=preg_replace('/\.[^.]+$/','',$name)??$name; $name=preg_replace('/[_\-]+/',' ',$name)??$name; $name=preg_replace('/[\[\]\{\}\(\)]/',' ',$name)??$name; $name=preg_replace("/[^\\pL\\pN\\s.!?\'’&,:-]/u",' ',$name)??$name; $name=preg_replace('/\s+/',' ',$name)??$name; return trim($name); }
function render(string $view,array $data=[]): void { extract($data); require __DIR__.'/../public/views/layout.php'; }
function is_cli(): bool { return PHP_SAPI==='cli'; }
