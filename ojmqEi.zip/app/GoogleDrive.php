<?php
declare(strict_types=1);
final class GoogleDrive {
 public function __construct(private string $accessToken) {}
 private function request(string $method,string $url,?string $body=null,array $headers=[]): array {
  $ch=curl_init($url); $headers[]='Authorization: Bearer '.$this->accessToken; if($body!==null)$headers[]='Content-Type: application/json';
  curl_setopt_array($ch,[CURLOPT_CUSTOMREQUEST=>$method,CURLOPT_RETURNTRANSFER=>true,CURLOPT_HTTPHEADER=>$headers,CURLOPT_TIMEOUT=>120,CURLOPT_CONNECTTIMEOUT=>30,CURLOPT_FOLLOWLOCATION=>true]);
  if($body!==null)curl_setopt($ch,CURLOPT_POSTFIELDS,$body); $raw=curl_exec($ch); if($raw===false){$e=curl_error($ch);curl_close($ch);throw new RuntimeException('Drive API: '.$e);} $status=curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);$json=json_decode($raw,true); if($status>=400)throw new RuntimeException('Drive API HTTP '.$status.': '.($json['error']['message']??$raw)); return is_array($json)?$json:[];
 }
 public function folder(string $folderId): array { return $this->request('GET','https://www.googleapis.com/drive/v3/files/'.rawurlencode($folderId).'?fields=id,name,mimeType,trashed&supportsAllDrives=true'); }
 public function about(): array { return $this->request('GET','https://www.googleapis.com/drive/v3/about?fields=user(displayName,emailAddress)'); }
 public function listVideos(string $folderId): array {
  $allowed=['video/mp4','video/quicktime','video/x-msvideo','video/x-matroska','video/webm','video/x-webm','video/mpeg','video/3gpp','video/ogg']; $all=[];$token=null;
  do { $params=['q'=>sprintf("'%s' in parents and trashed = false",str_replace("'","\\'",$folderId)),'pageSize'=>1000,'orderBy'=>'createdTime','fields'=>'nextPageToken,files(id,name,mimeType,size,createdTime,modifiedTime,capabilities)','supportsAllDrives'=>'true','includeItemsFromAllDrives'=>'true']; if($token)$params['pageToken']=$token; $r=$this->request('GET','https://www.googleapis.com/drive/v3/files?'.http_build_query($params)); foreach(($r['files']??[]) as $f){if(in_array(strtolower($f['mimeType']??''),$allowed,true)&&(($f['capabilities']['canDownload']??true)!==false))$all[]=$f;} $token=$r['nextPageToken']??null; } while($token);
  return $all;
 }
 public function downloadTo(string $fileId,string $path,int $maxBytes=0): int {
  $fp=fopen($path,'wb'); if(!$fp)throw new RuntimeException('Cannot open temporary download file.'); $url='https://www.googleapis.com/drive/v3/files/'.rawurlencode($fileId).'?alt=media'; $written=0;
  $ch=curl_init($url); curl_setopt_array($ch,[CURLOPT_FILE=>$fp,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_HTTPHEADER=>['Authorization: Bearer '.$this->accessToken],CURLOPT_TIMEOUT=>0,CURLOPT_CONNECTTIMEOUT=>30,CURLOPT_NOPROGRESS=>false,CURLOPT_PROGRESSFUNCTION=>function($r,$dlt,$dln)use($maxBytes){return ($maxBytes>0&&$dln>$maxBytes)?1:0;}]); $ok=curl_exec($ch);$status=curl_getinfo($ch,CURLINFO_HTTP_CODE);$err=curl_error($ch);curl_close($ch);fclose($fp);$written=(int)(filesize($path)?:0); if($ok===false||$status>=400){@unlink($path);throw new RuntimeException('Drive download HTTP '.$status.': '.($err?:'download failed'));} if($maxBytes>0&&$written>$maxBytes){@unlink($path);throw new RuntimeException('Video exceeds configured temporary file limit.');} return $written;
 }
}
