<?php
declare(strict_types=1);
final class Scheduler {
 public function __construct(private Database $db) {}
 public function nextSlot(int $channelId,?string $afterUtc=null): ?array {
  $rows=$this->db->all("SELECT * FROM upload_schedules WHERE youtube_channel_id=? AND enabled=1 ORDER BY day_of_week,upload_time",[$channelId]); if(!$rows)return null;
  $start=new DateTimeImmutable($afterUtc?:gmdate('Y-m-d H:i:s'),new DateTimeZone('UTC')); $start=$start->modify('+1 second');
  for($d=0;$d<370;$d++){
   $base=$start->modify("+$d day");$dow=(int)$base->setTimezone(new DateTimeZone('UTC'))->format('w');
   foreach($rows as $row){if((int)$row['day_of_week']!==$dow)continue; try{$tz=new DateTimeZone($row['timezone']);}catch(Throwable){continue;} $localDate=$base->setTimezone($tz)->format('Y-m-d'); $candidateLocal=new DateTimeImmutable($localDate.' '.$row['upload_time'],$tz); $candidateUtc=$candidateLocal->setTimezone(new DateTimeZone('UTC')); if($candidateUtc <= $start)continue; $candidate=$candidateUtc->format('Y-m-d H:i:s'); $used=$this->db->one("SELECT id FROM videos WHERE youtube_channel_id=? AND scheduled_at=? AND status IN ('Queued','Scheduled','Uploading') LIMIT 1",[$channelId,$candidate]); if(!$used)return ['utc'=>$candidate,'timezone'=>$row['timezone']]; }
  } return null;
 }
 public function scheduleVideo(int $videoId): ?string {
  $v=$this->db->one('SELECT * FROM videos WHERE id=?',[$videoId]); if(!$v)return null; if((int)$v['manual_schedule']===1&&$v['scheduled_at'])return $v['scheduled_at']; $slot=$this->nextSlot((int)$v['youtube_channel_id']); if(!$slot)return null; $this->db->exec("UPDATE videos SET scheduled_at=?,scheduled_timezone=?,status='Scheduled',updated_at=? WHERE id=?",[$slot['utc'],$slot['timezone'],now_sql(),$videoId]); return $slot['utc'];
 }
}
